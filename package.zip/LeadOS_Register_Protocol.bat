@echo off
title Lead OS — Register Auto-Start Protocol
cd /d "%~dp0"

echo.
echo =============================================
echo   Lead OS — One-time Protocol Registration
echo =============================================
echo.

:: Get current folder path (remove trailing backslash)
set FOLDER=%~dp0
if "%FOLDER:~-1%"=="\" set FOLDER=%FOLDER:~0,-1%

:: Create the launcher VBS (runs node silently in background)
echo Set WshShell = CreateObject("WScript.Shell") > "%FOLDER%\LeadOS_launcher.vbs"
echo WshShell.Run "cmd /c cd /d ""%FOLDER%"" && (if not exist node_modules\whatsapp-web.js npm install) && node LeadOS_server.js", 0, False >> "%FOLDER%\LeadOS_launcher.vbs"

:: Register leados:// protocol in Windows Registry
reg add "HKCU\Software\Classes\leados" /ve /d "URL:Lead OS Protocol" /f >nul
reg add "HKCU\Software\Classes\leados" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\leados\shell\open\command" /ve /d "wscript.exe \"%FOLDER%\LeadOS_launcher.vbs\"" /f >nul

echo =============================================
echo   SUCCESS! Protocol registered.
echo.
echo   Now click "Start Server" button in
echo   Lead OS — server will start automatically!
echo =============================================
echo.
pause
