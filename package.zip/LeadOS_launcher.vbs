Set WshShell = CreateObject("WScript.Shell") 
WshShell.Run "cmd /c cd /d ""E:\Lead OS"" && (if not exist node_modules\whatsapp-web.js npm install) && node LeadOS_server.js", 0, False 
