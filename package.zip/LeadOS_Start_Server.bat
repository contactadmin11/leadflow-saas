@echo off
title Lead OS Server - Running

:: Go to the folder where THIS bat file is located (works from any drive/path)
cd /d "%~dp0"

:start
cls
echo.
echo  ============================================
echo    Lead OS Server - Starting...
echo    Folder: %~dp0
echo  ============================================
echo.

:: Check Node.js installed
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not found!
    echo Download from: https://nodejs.org
    pause
    exit
)

:: Install packages only if missing
if not exist "node_modules\whatsapp-web.js" (
    echo Installing packages first time - please wait 2-3 min...
    npm install
    echo Done!
    echo.
)

echo  Server starting...
echo  Keep this window open!
echo.

:: Start the server
node LeadOS_server.js

:: Auto restart if crashes
echo.
echo  Server stopped - auto restarting in 5 seconds...
echo  Close this window to stop completely.
timeout /t 5 /nobreak >nul
goto start
